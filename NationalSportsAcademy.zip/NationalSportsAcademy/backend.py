from dotenv import load_dotenv
from flask import Flask, jsonify
from flask_cors import CORS
import psycopg2
from psycopg2.extras import RealDictCursor
import os
load_dotenv()

app = Flask(__name__)
CORS(app)


def get_db_connection():
    return psycopg2.connect(
        host="127.0.0.1",
        port=6543,
        database="sports_academy",
        user=os.getenv("DB_USER", "postgres"),
        password=os.environ["DB_PASSWORD"]
    )


@app.route("/")
def home():
    return "National Sports Academy Backend is running!"


@app.route("/api/athletes", methods=["GET"])
def get_athletes():
    conn = None

    try:
        conn = get_db_connection()

        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute("""
                SELECT full_name, status
                FROM athletes
                ORDER BY full_name;
            """)
            athletes = cursor.fetchall()

        return jsonify(athletes)

    except Exception:
        app.logger.exception("Failed to fetch athletes")
        return jsonify({
            "error": "Could not fetch athletes. Check the backend terminal."
        }), 500

    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=True)
