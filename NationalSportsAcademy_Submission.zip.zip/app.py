
from flask import Flask, jsonify, request
from flask_cors import CORS
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)
def get_db_connection():
    return psycopg2.connect(
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "tsdb"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        sslmode="require"
    )

@app.route("/")
def home():
    return "National Sports Academy Management System API is running!"

@app.route("/api/athletes")
def get_athletes():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT athlete_id, athlete_name, status
            FROM athletes
            ORDER BY athlete_id;
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()

        athletes = [
            {
                "athlete_id": row[0],
                "athlete_name": row[1],
                "status": row[2]
            }
            for row in rows
        ]
        return jsonify(athletes)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

def fetch_table_data(query):
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(query)
        columns = [desc[0] for desc in cur.description]
        rows = cur.fetchall()
        cur.close()

        return [
            dict(zip(columns, row))
            for row in rows
        ]
    finally:
        conn.close()


@app.route("/api/sports")
def get_sports():
    try:
        return jsonify(fetch_table_data(
            "SELECT * FROM sports ORDER BY sport_id"
        ))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/teams")
def get_teams():
    try:
        return jsonify(fetch_table_data(
            "SELECT * FROM teams ORDER BY team_id"
        ))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/training-sessions")
def get_training_sessions():
    try:
        return jsonify(fetch_table_data(
            "SELECT * FROM training_sessions"
        ))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/competitions")
def get_competitions():
    try:
        return jsonify(fetch_table_data(
            "SELECT * FROM competitions ORDER BY competition_id"
        ))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/fitness-assessments")
def get_fitness_assessments():
    try:
        return jsonify(fetch_table_data(
            "SELECT * FROM fitness_assessments ORDER BY assessment_id"
        ))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/athletes", methods=["POST"])
def add_athlete():
    data = request.get_json(silent=True) or {}

    name = data.get("athlete_name", "").strip()
    status = data.get("status", "Active").strip()

    if not name:
        return jsonify({"error": "Athlete name is required"}), 400

    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO athletes (athlete_name, status)
            VALUES (%s, %s)
            RETURNING athlete_id, athlete_name, status;
            """,
            (name, status)
        )
        row = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()

        return jsonify({
            "athlete_id": row[0],
            "athlete_name": row[1],
            "status": row[2]
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/athletes/<int:athlete_id>", methods=["PUT"])
def update_athlete(athlete_id):
    data = request.get_json(silent=True) or {}

    name = data.get("athlete_name", "").strip()
    status = data.get("status", "").strip()

    if not name or not status:
        return jsonify({
            "error": "Athlete name and status are required"
        }), 400

    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            """
            UPDATE athletes
            SET athlete_name = %s, status = %s
            WHERE athlete_id = %s
            RETURNING athlete_id, athlete_name, status;
            """,
            (name, status, athlete_id)
        )
        row = cur.fetchone()

        if row is None:
            conn.rollback()
            cur.close()
            conn.close()
            return jsonify({"error": "Athlete not found"}), 404

        conn.commit()
        cur.close()
        conn.close()

        return jsonify({
            "athlete_id": row[0],
            "athlete_name": row[1],
            "status": row[2]
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/athletes/<int:athlete_id>", methods=["DELETE"])
def delete_athlete(athlete_id):
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "DELETE FROM athletes WHERE athlete_id = %s RETURNING athlete_id;",
            (athlete_id,)
        )
        row = cur.fetchone()

        if row is None:
            conn.rollback()
            cur.close()
            conn.close()
            return jsonify({"error": "Athlete not found"}), 404

        conn.commit()
        cur.close()
        conn.close()

        return jsonify({
            "message": "Athlete deleted successfully",
            "athlete_id": row[0]
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
