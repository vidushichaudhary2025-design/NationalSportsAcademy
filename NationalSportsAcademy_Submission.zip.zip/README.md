 National Sports Academy Management System

 Project Overview
The National Sports Academy Management System is a web-based application for managing sports academy information using PostgreSQL and TimescaleDB.

 Technologies Used
- Python
- Flask
- PostgreSQL
- TimescaleDB
- HTML, CSS, and JavaScript

 Features
- View athletes
- View sports and teams
- View training sessions
- View competitions
- View fitness assessments
- Add, update, and delete athlete records

 Setup Instructions
1. Install Python.
2. Install the required packages using `pip install -r requirements.txt`.
3. Configure the database connection using your own local environment variables.
4. Run the application using `python app.py`.
5. Open the frontend dashboard in a browser.

 Database
The project uses PostgreSQL with TimescaleDB for storing sports academy data, including wearable data.

 Security
Database passwords and credentials should be kept private and must not be included in the submitted project files.
